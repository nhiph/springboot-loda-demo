package dev.nhiph;

import lombok.Data;

@Data
public class Todo {
    public String title;
    public String detail;
}