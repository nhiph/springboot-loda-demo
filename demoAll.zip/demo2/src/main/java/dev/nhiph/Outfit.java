package dev.nhiph;

import org.springframework.stereotype.Component;

public interface Outfit {
    public void wear();
}