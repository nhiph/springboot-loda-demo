package dev.nhiph;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo7ApplicationTests {

    @Test
    void contextLoads() {
    }

}
