package dev.nhiph;

public interface Outfit {
    public void wear();
}